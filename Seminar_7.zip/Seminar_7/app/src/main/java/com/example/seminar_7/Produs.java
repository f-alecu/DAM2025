package com.example.seminar_7;

import java.io.Serializable;

public class Produs implements Serializable {
    String Denumire;
    double Pret;

    Produs(String d, double p){
        Denumire = d;
        Pret = p;
    }

    public Produs() {
        Denumire = "";
        Pret = 0;
    }

    @Override
    public String toString() {
        return "Produs{" +
                "Denumire='" + Denumire + '\'' +
                ", Pret=" + Pret +
                '}';
    }
}
