package com.example.seminar_7;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import org.w3c.dom.Text;

public class MainActivity2 extends AppCompatActivity {

    boolean editMode = false;
    public static final String ADD_PRODUS = "addProdus";
    public static final String EDIT_PRODUS = "editProdus";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main2);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        Intent intent = getIntent();
        if(intent.hasExtra("editProdus")){

            Produs p = (Produs) intent.getSerializableExtra("editProdus");

            EditText txtD = (EditText) findViewById(R.id.editDenumire);
            EditText txtP = (EditText) findViewById(R.id.editPret);

            txtD.setText(p.Denumire);
            txtP.setText(String.valueOf(p.Pret));

            editMode = true;
        }

    }

    public void doSave(View view) {
        EditText txtD = (EditText) findViewById(R.id.editDenumire);
        EditText txtP = (EditText) findViewById(R.id.editPret);

        if (txtP.getText().toString().isEmpty() || txtD.getText().toString().isEmpty()) {
            Toast.makeText(this, "EMPTY!!!!!!", Toast.LENGTH_SHORT).show();
            return;
        }

        if (Double.parseDouble(txtP.getText().toString()) < 0) {
            Toast.makeText(this, "Errror!!!", Toast.LENGTH_SHORT).show();
            return;
        }

        Produs p = new Produs();
        p.Denumire = txtD.getText().toString().trim();
        p.Pret = Double.parseDouble(txtP.getText().toString().trim());

        Intent intent = getIntent();

        if (editMode)
            intent.putExtra("editProdus", p);
        else
            intent.putExtra("addProdus", p);

        setResult(RESULT_OK, intent);
        finish();
    }
}