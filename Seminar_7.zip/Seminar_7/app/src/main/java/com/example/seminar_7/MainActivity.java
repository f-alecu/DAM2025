package com.example.seminar_7;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.util.ArrayList;
import java.util.List;
import java.util.Collections;
import java.util.Comparator;
import java.util.Random;

public class MainActivity extends AppCompatActivity implements AdapterView.OnItemClickListener, AdapterView.OnItemLongClickListener {
    ArrayList<Produs>  listaProduse= new ArrayList<>();
    ListView list;

    int pozitie_lista;

    int REQUEST_CODE_ADD = 100;
    int REQUEST_CODE_EDIT = 200;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        Random rnd = new Random();

        for (int i=0; i<10; i++) {
            int N = rnd.nextInt(1000);

            Produs p = new Produs();
            p.Denumire = "Produs#" + N;
            p.Pret = rnd.nextInt(100) / 5.0;

            listaProduse.add(p);
            Log.e("###", p.toString());
        }



        list = (ListView) findViewById(R.id.listView);
        list.setOnItemClickListener(this);
        list.setOnItemLongClickListener(this);

        Collections.sort(listaProduse, new Comparator<Produs>() {
            @Override
            public int compare(Produs p1, Produs p2) {
                if (p1.Pret < p2.Pret)
                    return 1;
                else if (p1.Pret > p2.Pret)
                    return -1;
                else
                    return 0;
            }
        });

        ArrayAdapter<Produs> arr;
        arr = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, listaProduse);
        list.setAdapter(arr);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == REQUEST_CODE_ADD && resultCode == RESULT_OK && data != null){
            // add ok
            Produs p = (Produs) data.getSerializableExtra(MainActivity2.EDIT_PRODUS);
            if (p != null) {

                ArrayAdapter<Produs> arr = (ArrayAdapter<Produs>) list.getAdapter();
                listaProduse.add(p);

                Collections.sort(listaProduse, new Comparator<Produs>() {
                    @Override
                    public int compare(Produs p1, Produs p2) {
                        if (p1.Pret < p2.Pret)
                            return 1;
                        else if (p1.Pret > p2.Pret)
                            return -1;
                        else
                            return 0;
                    }
                });

                arr.notifyDataSetChanged();

            }
        }

        if (requestCode == REQUEST_CODE_EDIT && resultCode == RESULT_OK && data != null) {
            // edit
            Produs p = (Produs) data.getSerializableExtra(MainActivity2.EDIT_PRODUS);
            listaProduse.get(pozitie_lista).Denumire = p.Denumire;
            listaProduse.get(pozitie_lista).Pret = p.Pret;

            ArrayAdapter<Produs> arr = (ArrayAdapter<Produs>) list.getAdapter();

            Collections.sort(listaProduse, new Comparator<Produs>() {
                @Override
                public int compare(Produs p1, Produs p2) {
                    if (p1.Pret < p2.Pret)
                        return 1;
                    else if (p1.Pret > p2.Pret)
                        return -1;
                    else
                        return 0;
                }
            });

            arr.notifyDataSetChanged();
        }
    }

    public void doPress(View view) {
        Intent newA = new Intent(this, MainActivity2.class);
        startActivityForResult(newA, REQUEST_CODE_ADD);
    }

    @Override
    public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
        Toast.makeText(this, String.valueOf(position) + " - " + listaProduse.get(position).toString(), Toast.LENGTH_SHORT).show();
    }

    @Override
    public boolean onItemLongClick(AdapterView<?> parent, View view, int position, long id) {
        pozitie_lista = position;
        Intent newA = new Intent(this, MainActivity2.class);
        newA.putExtra("editProdus", listaProduse.get(position));
        startActivityForResult(newA, REQUEST_CODE_EDIT);
        return false;
    }
}