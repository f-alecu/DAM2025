package com.example.seminar4;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity3 extends AppCompatActivity implements View.OnClickListener {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main3);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
    }

    public void addNew(View view) {
        LinearLayout layout = findViewById(R.id.LinearLoyaltyID);
        Button newBtn = new Button(this);
        //newBtn.setId();
        newBtn.setText("Next Activity");
        newBtn.setOnClickListener(this);
        layout.addView(newBtn);
    }

    @Override
    public void onClick(View v) {
        Toast.makeText(this, "Clicked!!!", Toast.LENGTH_SHORT).show();
        Intent newActivity = new Intent(this, MainActivity4.class);
        startActivity(newActivity);
    }
}