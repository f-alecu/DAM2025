package com.example.seminar51;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        EditText et = (EditText) findViewById(R.id.editTextTextMultiLine);
        et.setText(et.getText() + "\n" + "onCreate()");

        Log.e("###1", "onCreate()");
    }

    @Override
    protected void onRestart() {
        super.onRestart();

        EditText et = (EditText) findViewById(R.id.editTextTextMultiLine);
        et.setText(et.getText() + "\n" + "onRestart()");

        Log.d("###1", "onRestart()");
    }

    public void doExit(View view) {
        AlertDialog dialog = new AlertDialog.Builder(MainActivity.this)
                .setTitle("Confirmare")
                .setMessage("Parasiti Aplicatia?")
                .setPositiveButton("DA!", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        dialogInterface.cancel();
                        finish();
                        System.exit(0);
                    }
                })
                .setNegativeButton("NU", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        dialogInterface.cancel();
                        Intent newA = new Intent(getApplicationContext(), MainActivity2.class);
                        startActivity(newA);
                    }
                })
                .create();

        dialog.show();




    }

    @Override
    protected void onStart() {
        super.onStart();

        EditText et = (EditText) findViewById(R.id.editTextTextMultiLine);
        et.setText(et.getText() + "\n" + "onStart()");

        Log.w("###1", "onStart()");
    }

    @Override
    protected void onStop() {
        super.onStop();

        EditText et = (EditText) findViewById(R.id.editTextTextMultiLine);
        et.setText(et.getText() + "\n" + "onStop()");

        Log.i("###1", "onStop()");
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();

        EditText et = (EditText) findViewById(R.id.editTextTextMultiLine);
        et.setText(et.getText() + "\n" + "onDestroy()");

        Log.e("###1", "onDestroy()");
    }

    @Override
    protected void onPause() {
        super.onPause();

        EditText et = (EditText) findViewById(R.id.editTextTextMultiLine);
        et.setText(et.getText() + "\n" + "onPause()");

        Log.e("###1", "onPause()");
    }

    @Override
    protected void onResume() {
        super.onResume();

        EditText et = (EditText) findViewById(R.id.editTextTextMultiLine);
        et.setText(et.getText() + "\n" + "onResume()");

        Log.e("###1", "onResume()");
    }
}