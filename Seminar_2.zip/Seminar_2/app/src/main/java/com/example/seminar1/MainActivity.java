package com.example.seminar1;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.util.Random;

public class MainActivity extends AppCompatActivity {


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);

            doShow(false);

            return insets;
        });
    }


    public void doShow(boolean mode){
        // image view
        ImageView iw = (ImageView) findViewById(R.id.imageView2);
        if (!mode)
            iw.setImageResource(R.drawable.big_star);
        else
            iw.setImageResource(R.drawable.big_star_off);

        // text view
        TextView tw = (TextView) findViewById(R.id.textView3);
        if (!mode)
            tw.setTextColor(Color.GRAY);
        else
            tw.setTextColor(Color.RED);

        Switch sw = (Switch) findViewById(R.id.switch2);
        Button bt = (Button) findViewById(R.id.button2);
        if (!mode)
            // enable the button
            bt.setVisibility(View.INVISIBLE);
        else if (sw.isChecked())
                bt.setVisibility(View.VISIBLE);

        // enable the switch
        sw.setEnabled(mode);
    }


    public void doEnableContent(View view) {
        // get the mode
        Switch sw = (Switch) findViewById(R.id.switch2);
        boolean mode = !sw.isEnabled();

        doShow(mode);
    }

    public void doSwitch(View view) {
        Switch sw = (Switch) findViewById(R.id.switch2);
        Button bt = (Button) findViewById(R.id.button2);
        if (sw.isChecked())
            bt.setVisibility(View.VISIBLE);
        else
            bt.setVisibility(View.INVISIBLE);
    }

    public void btnClicked(View view){
        //Toast.makeText(this, "Button Pressed!!!", Toast.LENGTH_LONG).show();
        Random r = new Random();

        Intent newActivity = new Intent(this, MainActivity2.class);
        newActivity.putExtra(Intent.EXTRA_TEXT, "Seminar 1 - Activitatea 2 ::: " + String.valueOf(r.nextInt(1000)));
        startActivity(newActivity);
    }
}