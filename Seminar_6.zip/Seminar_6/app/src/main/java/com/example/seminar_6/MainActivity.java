package com.example.seminar_6;

import android.content.DialogInterface;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.text.InputType;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity implements DialogInterface.OnCancelListener, DialogInterface.OnDismissListener {

    String appCode;
    boolean noDismiss;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);

        noDismiss = false;

        // get shared preferences
        SharedPreferences sp = getSharedPreferences("App_Access", MODE_PRIVATE);
        appCode = sp.getString("app_code", "");

        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        if (appCode.isEmpty()){
            builder.setTitle("DEFINE App Code...");}
        else {
            builder.setTitle("INPUT App Code...");}

        builder.setCancelable(false);

        final EditText input = new EditText(this);
        input.setHint("Your App Code, please.");
        input.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
        builder.setView(input);

        builder.setPositiveButton("OK", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {

                if (input.getText().toString().isEmpty())
                    dialog.cancel();

                if (appCode.isEmpty()) {
                    appCode = input.getText().toString();
                    SharedPreferences.Editor editor = sp.edit();
                    editor.putString("app_code", appCode);
                    editor.apply();
                    //dialog.dismiss();
                }

               if (!appCode.equals(input.getText().toString())) {
                    input.setText("");
                    input.setHint("Your App Code, please.");
                    Toast.makeText(MainActivity.this, "Wrong App Code! Try again...", Toast.LENGTH_SHORT).show();
                    dialog.cancel();
                }
               else
                   dialog.dismiss();


                   //Toast.makeText(MainActivity.this, input.getText().toString(), Toast.LENGTH_SHORT).show();

            }
        });

        builder.setNegativeButton("CANCEL", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                //dialog.cancel();
                finish();
                System.exit(0);
            }
        });

        builder.setOnCancelListener(this);
        builder.setOnDismissListener(this);

        builder.show();






    }

    @Override
    public void onCancel(DialogInterface dialog) {
        noDismiss = true;
        ((AlertDialog) dialog).show();
    }

    @Override
    public void onDismiss(DialogInterface dialog) {

        if (noDismiss){
            noDismiss = false;
            return;

        }


        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });


        TextView tv = (TextView) findViewById(R.id.textView3);
        tv.setText(appCode);
//        Toast.makeText(this, "DISMISSSSSSSSSSSS", Toast.LENGTH_SHORT).show();
    }

    public void doSPreset(View view) {
        SharedPreferences sp = getSharedPreferences("App_Access", MODE_PRIVATE);
        SharedPreferences.Editor editor = sp.edit();
        editor.putString("app_code", "");

        TextView tv = (TextView) findViewById(R.id.textView3);
        tv.setText("");

        editor.apply();
    }

    public void doExit(View view) {
        finish();
        System.exit(0);
    }
}